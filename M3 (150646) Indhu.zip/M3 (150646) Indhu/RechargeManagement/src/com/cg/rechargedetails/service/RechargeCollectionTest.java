/****** Author Name:Indhu Emp Id:150646  Date:05.07.2018******/
//Purpose: To provide test cases of RechargeDetails

package com.rechargedetails.service;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import org.junit.Assert;
import com.rechargedetails.bean.RechargeDetails;
import com.rechargedetails.exception.ListException;



import com.dthoperator.bean.RechargeDetails;



/**
 * @author trainee
 *
 */
public class RechargeCollectionTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}
	RechargeCollectionHelper r = new RechargeCollectionHelper();
	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@SuppressWarnings("deprecation")
//adding asseet details to the array list

	@Test(expected = ListException.class)
	public void testAddItems() throws ListException {
		
		r.addRechargeDetails(new RechargeDetails("Airtel", 1234567890, "Monthly", 123, 3698));
		Assert.assertEquals(2, r.getItems().size());
	}
	
	@Test
	public void testToAddNewDetails() throws ListException
	{
		r.addRechargeDetails(new RechargeDetails("TATASky", 987456321, "Monthly", 5620, 1478));
		Assert.assertNotEquals(1, r.getItems().size());
	}

	//clearing the assert details
	@Test 
	public void test()
	{
		r = null;
		Assert.assertNull(r);
		System.out.println(r);
	}

//checking whether asset details are present in array list
	@Test
	public void testcase()
	{
		RechargeCollectionHelper r = new RechargeCollectionHelper();
		RechargeCollectionHelper r1 = new RechargeCollectionHelper();
		Assert.assertNotEquals(1, 1);
	}

}
