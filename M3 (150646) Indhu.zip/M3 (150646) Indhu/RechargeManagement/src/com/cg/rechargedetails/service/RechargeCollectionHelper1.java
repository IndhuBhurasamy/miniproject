/****** Author Name:Indhu Emp Id:150646  Date:05.07.2018******/

package com.rechargedetails.service;

import com.rechargedetails.bean.RechargeDetails;
import com.rechargedetails.exception.ListException;

public interface RechargeCollectionHelper1 {
	public void addRechargeDetails(RechargeDetails rechargeDetails) throws ListException;
	
	public void displayRechargeDetails(int transacctionID);
	
}
