/******* Author Name: Indhu Emp Id : 150646  Date:05.07.2018 ******/
//Purpose: To provide getters and setters for book details

package com.dthoperator.bean;

public class RechargeDetails {

		String dthOperator;
		int consumerNo;
		String rechargePlan;
		int amount;
		int transactionID;
		
                   
	// initializing instance variables	
		public RechargeDetails(String dthOperator, int consumerNo, String rechargePlan, int amount, int transactionID) {
			super();
			this.dthOperator = dthOperator;
			this.consumerNo = consumerNo;
			this.rechargePlan = rechargePlan;
			this.amount = amount;
			this.transactionID = transactionID;
		}

		//getter for dth operator
		public String getDthOperator() {
			return dthOperator;
		}
                                   
                                    //setter for dth operator
		public void setDthOperator(String dthOperator) {
			this.dthOperator = dthOperator;
		}

                                   //getter for consumerno
		public int getConsumerNo() {
			return consumerNo;
		}

                                     //setter for consumerno
		public void setConsumerNo(int consumerNo) {
			this.consumerNo = consumerNo;
		}

                                   //getter for recharge plan
		public String getRechargePlan() {
			return rechargePlan;
		}

                                    //setter for recharge plan
		public void setRechargePlan(String rechargePlan) {
			this.rechargePlan = rechargePlan;
		}

                                   //getter for get amount
		public int getAmount() {
			return amount;
		}

                                    //setter for get amount
		public void setAmount(int amount) {
			this.amount = amount;
		}

                                   //getter for transaction id
		public int getTransactionID() {
			return transactionID;
		}

                                      //setter for transaction id
		public void setTransactionID(int transactionID) {
			this.transactionID = transactionID;
		}

                                     //displaying recharge details
		@Override
		public String toString() {
			return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo=" + consumerNo + ", rechargePlan="
					+ rechargePlan + ", amount=" + amount + ", transactionID=" + transactionID + "]";
		}
		
}
